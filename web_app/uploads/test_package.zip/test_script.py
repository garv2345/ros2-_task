print('hello world')
