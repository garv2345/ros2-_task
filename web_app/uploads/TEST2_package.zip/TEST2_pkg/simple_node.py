import rclpy
velocity = 1.5
print('System Safe')
