print('System Safe')
